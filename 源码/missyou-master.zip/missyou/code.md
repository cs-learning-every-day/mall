brew update
brew install redis

redis.conf is in /etc/redis.conf